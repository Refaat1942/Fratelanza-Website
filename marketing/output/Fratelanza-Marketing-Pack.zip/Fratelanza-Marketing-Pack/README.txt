FRATELANZA — MARKETING PACK
==========================
Every design carries a QR code that opens the Fratelanza website:
https://www.fratelanza.com/

01-Company-Profile-Booklet
  * ...-A5-for-email-and-screen.pdf  : 24-page bilingual booklet. Send to customers by e-mail / WhatsApp.
      Page 1 cover · 2 welcome & contents · 3-12 English · 13-22 Arabic (العربية) · 23 contact + QR · 24 back cover.
  * ...-PRINT-A4-duplex-fold-staple.pdf : same booklet arranged for printing.
      Print double-sided on A4 (flip on SHORT edge), 100% scale (no "fit to page"), stack the 6 sheets in order,
      fold in half and staple twice on the fold -> A5 booklet. Use borderless printing or ask the print shop to trim.
  * For a print shop: give them the A5 file (or ask them to impose it) and request 3 mm bleed if they need it.

02-Print-Designs-with-QR
  One PDF per item at real size with 3 mm bleed and crop marks (folder with fold ticks). See the design guide.
  Colours are RGB — the printer should convert to CMYK / Pantone and show a physical proof before the full run.

05-Simple-Arabic-Profile
  2-page A4 Egyptian-Arabic flyer: custom-built systems, source code delivered, no subscriptions, 3 months free support.

03-Design-Guide
  Overview of all items, brand colours, fonts and printer notes (English + Arabic).

04-QR-Code
  Fratelanza-Links-QR.svg / .png for any extra use (posters, WhatsApp status, screens).

QR tips: keep on white, do not recolour or shrink, and test-scan a printed proof with two phones.
Each item's QR has its own tag (utm_source=qr-<item>) so scans are tracked per item in the site's analytics.

-------------------------------------------------------------------------
فراتيلانزا — الحزمة التسويقية
كل تصميم يحتوي على كود QR يفتح موقع فراتيلانزا:
https://www.fratelanza.com/

01 — كتيّب الملف التعريفي (ثنائي اللغة): نسخة A5 للإرسال بالبريد وواتساب، ونسخة A4 جاهزة للطباعة على الوجهين (اقلب على الحافة القصيرة)،
   بمقياس 100% دون "ملاءمة الصفحة"، ثم رتّب الأوراق الست واطوِها من المنتصف وثبّتها بدبّوس مرتين على خط الطي.
   الصفحات: ١ الغلاف · ٢ الترحيب والمحتويات · ٣–١٢ الإنجليزية · ١٣–٢٢ العربية · ٢٣ التواصل و QR · ٢٤ الغلاف الخلفي.
02 — التصاميم المطبوعة: ملف لكل منتج بالمقاس الحقيقي مع هامش قص ٣ مم وعلامات القص. الألوان RGB وتُحوَّل إلى CMYK في المطبعة مع طلب عينة.
03 — دليل التصميم: نظرة عامة وألوان وخطوط وملاحظات للمطبعة.
04 — QR: ملفات الكود (SVG / PNG) لأي استخدام آخر.
نصيحة: اجعل الكود على خلفية بيضاء، لا تغيّر لونه ولا تصغّره، وجرّب مسحه من نسخة مطبوعة قبل الطباعة الكاملة.
